export interface UserData {
  email: string;
  password: string;
  name: string;
  hometown: string;
}