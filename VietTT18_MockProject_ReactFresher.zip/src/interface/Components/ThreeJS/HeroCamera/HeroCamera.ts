
export interface IHeroCamera {
  isMobile: boolean;
  children: React.ReactNode;
}