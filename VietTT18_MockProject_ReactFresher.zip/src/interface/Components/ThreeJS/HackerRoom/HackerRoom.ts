export interface IHackerRoom {
  position?: [number, number, number];
  scale?: [number, number, number];
  rotation?: [number, number, number];
}