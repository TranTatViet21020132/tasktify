export interface IObject {
  position?: [number, number, number];
  scale?: [number, number, number];
  rotation?: [number, number, number];
}
