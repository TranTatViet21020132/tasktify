export interface ITaskFilter {
  page?: number;
  limit?: number;
  title?: string;
  completed?: boolean;
}