export const BASE_TASK_URL = 'https://673ce3064db5a341d8334cc9.mockapi.io/';

export const BASE_WEATHER_URL = 'https://api.weatherapi.com/v1';

export const WEATHER_API_KEY = import.meta.env.VITE_WEATHER_API_KEY;