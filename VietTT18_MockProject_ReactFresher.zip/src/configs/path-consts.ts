export const LOG_IN_ROUTE: string =  "/login";

export const SIGN_UP_ROUTE: string =  "/signup";

export const HOME_ROUTE: string =  "/home";

export const TASK_TABLE_ROUTE: string =  "/task-table";

export const TASK_LIST_ROUTE: string =  "/task-list";
